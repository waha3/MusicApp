import HomeStore from './homeStore.js';

const store = {
  homeStore: new HomeStore()
}

export default store;