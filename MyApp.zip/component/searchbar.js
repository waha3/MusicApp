import React, { Component } from 'react';
import { SearchBar } from 'antd-mobile';

export default class SearchBarCom extends Component {
  render() {
    return (
      <SearchBar />
    );
  }
}