import { StackNavigator } from 'react-navigation';
import Home from './container/home.js';
import NavigatorBar from './component/tabbar.js';

const RootStack = StackNavigator({
  Main: {
    screen: NavigatorBar,
    navigationOptions: {
      header: null
    }
  },
  Home: {
    screen: Home,
    navigationOptions: {
      header: null
    }
  }
});

export default RootStack;