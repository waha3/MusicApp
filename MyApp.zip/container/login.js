import React, { Component } from 'react';
import { View, StyleSheet, TextInput, Button } from 'react-native';
import { WhiteSpace, WingBlank } from 'antd-mobile';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  button: {
    borderColor: '#d43c33',
    borderWidth: 1,
    borderRadius: 25
  }
})

export class LoginButton extends Component {
  render() {
    return (
      <WingBlank style={styles.container}>
        <Button style={styles.button}>手机号登录</Button>
      </WingBlank>
    );
  }
}

export class LoginForm extends Component {
  onButtonPress = () => {}

  render() {
    return (
      <WingBlank>
        <WhiteSpace />
        <TextInput
          placeholder="手机号"
        />
        <TextInput
          placeholder="密码"
        />
        <WhiteSpace />
        <Button
          onPress={this.onButtonPress}
          title="登录"
          accessibilityLabel="See an informative alert"
        />
      </WingBlank>
    );
  }
}