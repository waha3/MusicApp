import React, { Component } from 'react';
import { Provider } from 'mobx-react';
import store from './mobx/index.js';
import RootStack from './route.js';
import { LoginButton, LoginForm } from './container/login.js';

export default class App extends Component {
  render() {
    return (
      <Provider {...store}>
        <LoginForm />
      </Provider>
    );
  }
}
